#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""A correlated private values auction, with private values independent
conditional on a state of the world.  Similar to Kagel et al, Ecma 1987.
"""

import argparse

import numpy
import sympy

import auction
import enumerator

class TwoSignalWalletAuction(auction.ConditionalSignalsAuction):
    """Variation on two-signal auction, where value has the generalized
    wallet game structure: value is gamma * own signal + (1-gamma) * other signal.

    The case of private values (gamma=1) is considered in the paper.
    """
    def __init__(self, values, gamma, p=sympy.Rational(1,2)):
        self.values = values
        self.gamma = gamma
        self.p = p
        auction.ConditionalSignalsAuction.__init__(self)

    def f(self, m):
        "Probability of value v_m being realized."
        if m > 0:
            return sympy.Rational(1, len(self.values) - 1)
        else:
            return 0

    def g(self, k, m):
        "Probability of signal s_k given value v_m."
        if m == k:
            return self.p
        elif m == k+1:
            return 1 - self.p
        else:
            return 0

    def _compute_V(self):
        V = numpy.zeros([ len(self.values), len(self.values) ], sympy.Rational)
        for (k, sk) in enumerate(self.values):
            for (ell, sl) in enumerate(self.values):
                V[k,ell] = self.gamma * sk + (1-self.gamma) * sl
        return V

                        
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Solve Example 2 (affiliated private values with 2 values possible per state)')
    parser.add_argument('K', type=int,
                        help='number of values (uniformly spaced on [0, 1])')

    args = parser.parse_args()
    values = [ sympy.Rational(i, args.K)
               for i in xrange(1, args.K+1) ]
    game = TwoSignalWalletAuction(values, gamma=1)
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   enumerator.EquilibriumList())
