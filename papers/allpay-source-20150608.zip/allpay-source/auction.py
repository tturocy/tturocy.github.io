#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""Base representation classes for two-bidder interdependent values all-pay
auctions.

As a terminology note: throughout we use 'signal' instead of 'type', as is used
in the paper.  The word 'type' is already used in the Python language, and as
such using 'type' here could lead to confusion.
"""

import StringIO
import numpy
import sympy
from sympy import Rational

class InterdependentValuesAuction(object):
    """
    Defines the superstructure shared by all instances of the
    interdependent values auction environment.
    """
    def __init__(self):
        self._psi = self._compute_h().transpose() * self._compute_V()

    def _compute_h(self):
        raise NotImplementedError("_compute_h() must be provided by the subclass.")

    def _compute_V(self):
        raise NotImplementedError("_compute_V() must be provided by the subclass.")
    
    @property
    def psi(self):  return self._psi

    def h(self, ell, k):
        return self._compute_h()[ell,k]

    def posterior(self, k):
        "Compute the posterior expected value given type k"
        return sum(self._psi[k,:])

    def payoff(self, k, b, Pi):
        """
        Compute expected payoff to signal k of bid b, assuming the CDF of
        all signals at b is the vector Pi.
        """
        return self._psi[k,:].dot(Pi) - b
        
    def deriv(self, k, pi):
        """
        Compute the derivative of payoff to signal k, assuming the
        PDF of all signals at the bid is the vector pi.
        """
        return self._psi[k,:].dot(pi) - 1

class ConditionalSignalsAuction(InterdependentValuesAuction):
    """
    Defines an auction environment where the information and value structure
    is expressed in terms of a true common value with some common prior
    f(value), and signals generated conditional on that value by
    g(signal | value).

    In this setting, we identify the set of signals to be equal to the
    set of values, as a notational convenience.
    """
    def f(self, m): 
        "Probability of value v[m] being realized."
        raise NotImplementedError("f() must be provided by the subclass.")
    def g(self, k, m):
        "Probability of signal s[k] given value v[m]."
        raise NotImplementedError("g() must be provided by the subclass.")

    @property
    def signal_count(self):  return len(self.values)
    @property
    def signals(self):       return self.values
        
    def _compute_h(self):
        """
        Compute array of conditional signal probabilities h.
        Entry h[l,k] is h(s_l | s_k).
        """
        h = numpy.zeros([ len(self.values), len(self.values) ],
                        sympy.Rational)
        for (k, sk) in enumerate(self.values):
            denom = sum([ self.f(m) * self.g(k, m)
                          for (m, vm) in enumerate(self.values) ])
            for (l, sl) in enumerate(self.values):
                h[l,k] = sum([ self.f(m)*self.g(k,m)*self.g(l,m)
                               for (m, vm) in enumerate(self.values) ]) / denom
        return h
                
    def _compute_V(self):
        """
        Compute array of conditional values.
        Entry V[k,l] is V(s_k, s_l).
        """
        V = numpy.zeros([ len(self.values), len(self.values) ], sympy.Rational)
        for (k, sk) in enumerate(self.values):
            for (l, sl) in enumerate(self.values):
                try:
                    denom = sum([ self.f(m)*self.g(k,m)*self.g(l,m)
                                  for (m, vm) in enumerate(self.values) ])
                    if denom == 0:
                        # Combination of signals is not possible
                        V[k,l] = 0
                    else:
                        V[k,l] = sum([ vm*self.f(m)*self.g(k,m)*self.g(l,m)
                                       for (m, vm) in enumerate(self.values) ]) / \
                                       denom
                except ZeroDivisionError:
                    # If this occurs, combination cannot happen
                    V[k,l] = 0
        return V



