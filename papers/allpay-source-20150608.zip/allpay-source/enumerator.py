#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""
An enumeration algorithm for equilibria in symmetric two-bidder all-pay auctions.
"""

import sys
import os
import os.path
import StringIO

import numpy
import sympy
from sympy import Rational
from matplotlib import pyplot

import scipy.integrate

import networkx

import pydot


class ActiveSet(object):
    """A subset of signals in an auction game.
    """
    def __init__(self, game, active):
        self.game = game
        self.active = tuple(active)
        self.p = [ sympy.Symbol("%sp%d" %
                                (self.label.replace("-","x"), k))
                   for (k, vk) in enumerate(game.signals) ]

    def __repr__(self):
        return str(self.active)

    def __hash__(self):
        return hash(self.active)
        
    def __eq__(self, other):
        return self.game == other.game and self.active == other.active
    def __ne__(self, other):
        return self.game != other.game or self.active != other.active

    def __iter__(self):
        return iter(self.active)
    def __contains__(self, signal):
        return signal in self.active
    
    @property
    def label(self):
        return "".join([ "%d" % k if k in self.active else "-"
                         for (k, vk) in enumerate(self.game.signals) ])
    @property
    def summary(self):
        buf = StringIO.StringIO()
        for (k, v) in enumerate(self.p):
            print >>buf, "%s = %-20s %s" % (v, self.prob(k), self.deriv(k))
        return buf.getvalue()

    def _compute_solution(self):
        eqns = [ self.game.deriv(k, self.p) if k in self.active else self.p[k]
                 for (k, vk) in enumerate(self.game.signals) ]
        self._soln = sympy.solve(eqns, self.p)
        if self._soln == [ ]:
            self._soln = { }
            return
        self._deriv = [ self.game.deriv(k, self.p).subs(self._soln)
                        for (k, vk) in enumerate(self.game.signals) ]
    @property
    def solution(self):
        if not hasattr(self, "_soln"): self._compute_solution()
        return self._soln
    def prob(self, k):
        return self.solution[self.p[k]] \
               if self.p[k] in self.solution else self.p[k]
    def deriv(self, k):
        if not hasattr(self, "_deriv"):  self._compute_solution()
        return self._deriv[k]
        
    @property
    def is_admissible(self):
        if self.solution == { }:  return False
        for (v, prob) in self.solution.iteritems():
            if sympy.N(prob) < 0.0:
                return False
        return True
    @property
    def is_degenerate(self):  return len(self.soln) < len(self.p)
    @property
    def implicit_vars(self):
        return [ p for p in self.p if p not in self.solution ]

    def can_follow(self, s):
        "Returns True if this can succeed 's' in graph of admissible sets"
        if self == s:  return False
        joiners = set(self.active) - set(s.active)
        if len(joiners) > 0 and max([ s.deriv(k) for k in joiners ]) >= 0:
           return False
        leavers = set(s.active) - set(self.active)
        if len(leavers) > 0 and min([ self.deriv(k) for k in leavers ]) <= 0:
           return False
        return True
        

class AdmissibleSetEnumerator(object):
    """Enumerate the active sets in a game which are admissible.
    """
    def __init__(self, game):
        self._game = game

    def __iter__(self):
        def subsets(L):
            if len(L) == 0:
                yield [ ]
            else:
                for z in subsets(L[1:]):
                    yield [ L[0] ] + z
                    yield z

        for active in subsets(range(self._game.signal_count)):
            if len(active) == 0: continue
            s = ActiveSet(self._game, active)
            if s.is_admissible:
                yield s


class AdmissibleSetGraph(networkx.DiGraph):
    """Represents the directed graph Gamma of admissible active sets
    for a game.
    """
    def __init__(self, game):
        networkx.DiGraph.__init__(self)
        self.game = game
        self.add_nodes_from(AdmissibleSetEnumerator(game))
        for (i, n) in enumerate(self.nodes()):
            for m in self.nodes()[i+1:]:
                if n.can_follow(m):
                    self.add_edge(m, n)
                elif m.can_follow(n):
                    self.add_edge(n, m)

    def terminal_nodes(self):
        return [ n for n in self.nodes() if len(self.successors(n)) == 0 ]

    def render_graph(self, start):
        """Compute the graph of transitions available from 'start',
        restricting attention only to paths which contain all signals
        at least once.
        """
        # Also set nodesep, ranksep for further customization
        graph = pydot.Dot(graph_type='digraph', size="2.0,3.5",
                          orientation='portrait')
        edges = set()
        reachable = set()
        for node in self.terminal_nodes():
            for path in networkx.all_simple_paths(self, start, node):
                reached = set([ x for n in path for x in n ])
                if len(reached) < len(self.game.signals):
                    continue
                for (n1, n2) in zip(path[:-1], path[1:]):
                    edges.add((n1.label.replace("-", ""),
                               n2.label.replace("-", "")))
                for node in path:
                    reachable.add(node.label.replace("-",""))
        # Can also set height, width, fontsize to customize nodes
        # for large graphs
        nodes = dict((n, pydot.Node(n))
                     for n in reachable)
        for n in nodes.itervalues():
            graph.add_node(n)
        for (n1, n2) in edges:
            graph.add_edge(pydot.Edge(nodes[n1], nodes[n2]))
        return graph

class Candidate(object):
    """Encapsulates a candidate solution to the equilibrium equations.
    """
    def __init__(self, game, path, L, mu, solndict):
        self._game = game
        self._path = path
        self._L = L
        self._mu = mu
        self._vars = L + [ item for sublist in mu for item in sublist ]
        self._solndict = solndict
        for var in self._vars:
            if var not in self._solndict:
                # Degenerate solution: 'var' is a free variable
                self._solndict[var] = var

        self._maxbids = [ ]
        self._payoffs = [ ]
        for (k, s) in enumerate(game.signals):
            for (j, a) in enumerate(path):
                if k not in a.active: continue
                bid = sum([ solndict[L[j:][jj]] for (jj, aa) in enumerate(path[j:])])
                cdfs = [ sum([ solndict[mu[j:][jj][kk]] for (jj, aa) in enumerate(path[j:]) ])
                         for (kk, ss) in enumerate(game.signals) ]
                payoff = game.psi[k,:].dot(cdfs) - bid
                break
            self._maxbids.append(bid)
            self._payoffs.append(payoff)

    @property
    def game(self):   return self._game
        
    @property
    def is_nonnegative(self):
        for var in self._vars:
            if var in self._solndict and self._solndict[var] < 0:
                print "SOLUTION, but %s is negative" % var
                return False
        return True

    def payoff(self, k):   return self._payoffs[k]
    def maxbid(self, k):   return self._maxbids[k]

    def average_bid(self, k):
        bid, total = 0, 0.0
        for (i, L) in reversed(list(enumerate(self._L))):
            try:
                total += scipy.integrate.quad(lambda b: b*self.pdf(k, b),
                                              bid, bid+self._solndict[L])[0]
            except scipy.integrate.quadpack.error:
                return None
            bid += self._solndict[L]
        return total

    def cdf(self, k, b):
        bid, cdf = 0, 0
        for (i, L) in reversed(list(enumerate(self._L))):
            if b <= bid+self._solndict[L]:
                return cdf+self._solndict[self._mu[i][k]]*(b-bid)/self._solndict[L]
            bid += self._solndict[L]
            cdf += self._solndict[self._mu[i][k]]
        return 1

    def pdf(self, k, b):
        bid = 0
        for (i, L) in reversed(list(enumerate(self._L))):
            if b <= bid+self._solndict[L]:
                return self._solndict[self._mu[i][k]]/self._solndict[L]
            bid += self._solndict[L]
        return 0

    def wins(self, k1, k2):
        """Compute the probability that a bidder with signal k1
        defeats a bidder with signal k2.
        """
        bid, total = 0, 0.0
        for (i, L) in reversed(list(enumerate(self._L))):
            total += scipy.integrate.quad(lambda b: self.cdf(k2, b)*self.pdf(k1, b),
                                          bid, bid+self._solndict[L])[0]
            bid += self._solndict[L]
        return total

    def activity_plot(self, fn):
        pyplot.figure(figsize=(6/1.618*(len(self._game.signals)/5.0), 6))
        bid = 0
        for (i, L) in reversed(list(enumerate(self._L))):
            width = float(self._solndict[L])
            pyplot.plot([ -1, len(self.game.signals) ],
                        [ bid+width, bid+width ],
                         '--', color="0.5")
            for (k, s) in enumerate(self._game.signals):
                if self._solndict[self._mu[i][k]] != 0:
                    for delta in xrange(-10, +11, 1):
                        pyplot.plot([k+.01*delta, k+.01*delta],
                                    [bid, bid+width], '-',
                                    linewidth=2, color="0.0")
            bid += width

        pyplot.xticks([ k for (k, vk) in enumerate(self._game.signals) ],
                      [ "$t_{%d}$" % k
                        for (k, vk) in enumerate(self._game.signals) ],
                      fontsize=16)
        pyplot.yticks([ 0.00, 0.25, 0.50, 0.75, 1.00 ],
                      [ "$0.00$", "$0.25$", "$0.50$", "$0.75$", "$1.00$" ],
                      fontsize=16)
        pyplot.xlim([ -0.5, len(self.game.signals)-0.5 ])
        pyplot.xlabel("Type", family='serif', fontsize=16)
        pyplot.ylabel("Bid", family='serif', fontsize=16)
        pyplot.subplots_adjust(left=0.30)
        pyplot.savefig(fn+".eps", format="eps")
        pyplot.savefig(fn+".pdf", format="pdf")
        

        
def solve_path(game, path):
    L = [ sympy.Symbol("$L^%d$" % j) for (j, a) in enumerate(path) ]
    mu = [ [ sympy.Symbol("$mu^%d_%d$" % (j, k))
             for (k, s) in enumerate(game.signals) ]
           for (j, a) in enumerate(path) ]
    vars = L + [ item for sublist in mu for item in sublist ]

    eqns = [ ]

    # Equations for admissibility
    for (j, a) in enumerate(path):
        for (k, s) in enumerate(game.signals):
            if k not in a:
                eqns.append(mu[j][k])
            else:
                eqns.append(game.psi[k,:].dot(mu[j]) - L[j])

    # Equations for sum-to-one
    for (k, s) in enumerate(game.signals):
        eqns.append(sum([ mu[j][k] for (j, a) in enumerate(path) ]) - 1)

    # Equations for gaps in support
    for (k, s) in enumerate(game.signals):
        eq = None
        for (j, (a1, a2)) in enumerate(zip(path[:-1], path[1:])):
            if k in a1.active and k not in a2.active:
                eq = game.psi[k,:].dot(mu[j+1]) - L[j+1]
            elif eq is not None and k not in a2.active:
                eq += game.psi[k,:].dot(mu[j+1]) - L[j+1]
            elif eq is not None and k not in a1.active and k in a2.active:
                eqns.append(eq)
                eq = None
    soln = sympy.solve(eqns, vars)
    
    if isinstance(soln, list):
        if len(soln) == 0:
            print "NO SOLUTIONS."
            return
        else:
            solndict = dict(zip(I+extra_probs, soln[0]))
    else:
        solndict = soln

    candidate = Candidate(game, path, L, mu, solndict)
    if not candidate.is_nonnegative:
        return None

    for (k, s) in enumerate(game.signals):
        if candidate.payoff(k) < 0:
            print "SOLUTION, but payoff to %s is negative" % k
            return None
    print "EQUILIBRIUM FOUND."
    return candidate


# Because the number of paths through the graph of admissible active sets
# can be large, in this implementation we encapsulate the concept of a path
# enumerator.
#
# The generic enumerator here has the following features:
# * By default, sets the starting active set to be the one in which the
#   type with the highest posterior expected value conditional on the type
#   is the only active signal.  The caller can override this behaviour by
#   specifying a list of tuples of signals 'prefix', which specify to consider
#   only paths starting with that prefix.  
# * For each active set, sorts the successors in descending order by their
#   list of active types.  For games in which higher-indexed types imply
#   (conditionally) higher valuations, and in which types and values are
#   affiliated, this tends to result in finding the path(s) corresponding to
#   equilibria sooner.
# * Restricts attention to paths in which each active set appears at most one
#   time.  For games in which cycles can appear in the active set graph
#   (such as the identity-dependent example 5 in the paper), more sophisticated
#   heuristics may be considered.
class PathEnumerator(object):
    def __init__(self, game, start_active=None, prefix=[ ]):
        self._game = game
        self._graph = AdmissibleSetGraph(game)
        if start_active is None:
            start_signal = numpy.argmax([ game.posterior(k)
                                          for k in xrange(len(game.signals)) ])
            self._start_active = ActiveSet(game, (start_signal,))
        else:
            self._start_active = ActiveSet(game, start_active)
            if self._start_active not in self._graph.nodes():
                raise ValueError("Starting node %s not an admissible active set" % start_active)
        self._prefix = [ ActiveSet(game, x) for x in prefix ]
            
    @property
    def game(self):  return self._game
    @property
    def graph(self): return self._graph

    def _subpaths_from(self, start, path):
        if start in path:
            raise StopIteration
        reached = set()
        for node in path + [ start ]:
            reached = reached.union(set(node.active))
        if len(reached) == len(self._game.signals):
            yield path + [ start ]

        for node in sorted(self._graph.successors(start),
                           key=lambda x: x.active,
                           reverse=True):
            for ret in self._subpaths_from(node, path + [ start ]):
                yield ret

    def __iter__(self):
        for p in self._subpaths_from(self._start_active, self._prefix):
            yield p

class EquilibriumList(list):
    """Accumulator of list of equilibria found.  On adding a new entry,
    prints out a summary of the equilibrium and generates an activity plot.
    """
    def append(self, eqm):
        list.append(self, eqm)
        self._summarize(len(self)-1, eqm)
        
    def _summarize(self, i, eqm):
        print "EQUILIBRIUM SUMMARY:"
        for (j, a) in enumerate(eqm._path):
            print "Interval %d: signals %s, length = %s" % (j, a,
                                                             eqm._solndict[eqm._L[j]]),
            try:
                print "(%.6f)" % float(eqm._solndict[eqm._L[j]])
            except TypeError:
                # If lengths are degenerate, can't take a float
                print

            for (k, s) in enumerate(eqm.game.signals):
                if k not in a.active: continue
                print "  $mu_%d$: %s" % (k, eqm._solndict[eqm._mu[j][k]])
            print
        for (k, s) in enumerate(eqm.game.signals):
            print "Signal %2d:" % k,
            try:
                print "payoff=%9.6f," % eqm.payoff(k),
            except TypeError:
                print "payoff=%s," % eqm.payoff(k),
            try:
                print "maxbid=%9.6f" % eqm.maxbid(k)
            except TypeError:
                print "maxbid=%s" % eqm.maxbid(k)
        try:
            eqm.activity_plot("eqm-%03d" % i)
            print "Saved activity plot to 'eqm-%03d'." % i
        except TypeError:
            print "WARNING: Could not generate activity plot -- degenerate equilibria?"
            
def enumerate_solutions(game, path_enumerator, eqm_accumulator):
    for path in path_enumerator:
        print "-"*25
        print "Path:", path
        eqm = solve_path(game, path)
        if eqm is not None:
            eqm_accumulator.append(eqm)
        print
    return eqm_accumulator
    
