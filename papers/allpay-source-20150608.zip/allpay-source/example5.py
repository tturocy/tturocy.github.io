#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""Identity-dependent interdependent values example. (Example 5 from paper.)
"""

from sympy import Rational
import numpy

import auction
import enumerator

class IdentityDependentAuction(auction.InterdependentValuesAuction):
    def __init__(self):
        auction.InterdependentValuesAuction.__init__(self)

    @property
    def signal_count(self):   return 3
    @property
    def signals(self):       return [ Rational(1,3), Rational(2,3), Rational(1) ]
        
    def _compute_h(self):
        h = numpy.zeros([ 3, 3 ], Rational)
        h[0] = [ Rational(1,3), Rational(1,3), Rational(1,3) ]
        h[1] = [ Rational(1,3), Rational(1,3), Rational(1,3) ]
        h[2] = [ Rational(1,3), Rational(1,3), Rational(1,3) ]
        self._h = h
        return h

    def _compute_V(self):
        V = numpy.zeros([ 3, 3 ], Rational)
        V[0] = [ Rational(2,3), Rational(1,3), Rational(1) ]
        V[1] = [ Rational(1), Rational(2,3), Rational(1,3) ]
        V[2] = [ Rational(1,3), Rational(1), Rational(2,3) ]
        self._V = V
        return V



if __name__ == "__main__":
    game = IdentityDependentAuction()
    eqa = enumerator.EquilibriumList()

    graph = enumerator.AdmissibleSetGraph(game)
    print "Summary of graph structure:"
    for node in graph.nodes():
        print node
        for child in graph.successors(node):
            print "     ->", child
    print

    # First: There is an equilibrium where all three randomize over
    # the same interval
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game, (0,1,2)),
                                   eqa)
    
    # Next: There are equilibria in which each type randomizes over
    # just one interval.  The default PathEnumerator object automatically
    # stops traversing when it revisits an active set
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game, (2,)),
                                   eqa)
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game, (1,)),
                                   eqa)
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game, (0,)),
                                   eqa)

    # We can also manually construct paths and pass them to the enumerator.
    # This illustrates that if we visit the active set (2,) twice, there
    # is a one-dimensional set of solutions.
    enumerator.enumerate_solutions(game,
                                   [ [ enumerator.ActiveSet(game, x)
                                       for x in [ (2,), (1,), (0,), (2,) ] ] ],
                                   eqa)

    # Or, we could loop around another time, and again, another one-dimensional
    # set of solutions, where the interval lengths, excepting the top and bottom
    # ones, are one-half the previous example.
    enumerator.enumerate_solutions(game,
                                   [ [ enumerator.ActiveSet(game, x)
                                       for x in [ (2,), (1,), (0,),
                                                  (2,), (1,), (0,), (2,) ] ] ],
                                   eqa)

    enumerator.enumerate_solutions(game,
                                   [ [ enumerator.ActiveSet(game, x)
                                       for x in [ (2,), (1,), (0,),
                                                  (2,), (1,), (0,),
                                                  (2,), (1,), (0,), (2,) ] ] ],
                                   eqa)

    # As another possibility, we can traverse the cycle an integer number
    # of times.  We can do it twice:
    enumerator.enumerate_solutions(game,
                                   [ [ enumerator.ActiveSet(game, x)
                                       for x in [ (2,), (1,), (0,),
                                                  (2,), (1,), (0,) ] ] ],
                                   eqa)

    # Or we can do it three times:
    enumerator.enumerate_solutions(game,
                                   [ [ enumerator.ActiveSet(game, x)
                                       for x in [ (2,), (1,), (0,),
                                                  (2,), (1,), (0,),
                                                  (2,), (1,), (0,), ] ] ],
                                   eqa)

    # In both the above cases, however, note that one obtains an
    # equilibrium which is one of the equilibria from the example
    # with the path [ (2,), (1,), (0,), (2,) ], in that the total
    # bid lengths and probability masses associated with each
    # active set are the same.
