#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""Files for Example 1 in paper:
Common-value auction with conditionally independent signals.
"""

import argparse

import sympy

import auction
import enumerator

class MSignalAuction(auction.ConditionalSignalsAuction):
    """Auction with M signals per value, for any odd M.
    """
    def __init__(self, values, M):
        assert(M % 2 == 1)
        self.delta = M / 2
        self.values = [ values[0]-1 for i in xrange(self.delta) ] + values + \
                      [ values[-1]+1 for i in xrange(self.delta) ]
        auction.ConditionalSignalsAuction.__init__(self)
                
    def f(self, m):
        "Probability of value v_m being realized."
        if m < self.delta or m >= len(self.values) - self.delta:
            return 0
        else:
            return sympy.Rational(1, len(self.values) - 2*self.delta)

    def g(self, k, m):
        "Probability of signal s_k given value v_m."
        if abs(m-k) <= self.delta:
            return sympy.Rational(1, 1+2*self.delta)
        else:
            return 0

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Solve extension of Example 1 (common values with M signals possible per value)')
    parser.add_argument('K', type=int,
                        help='number of values (uniformly spaced on [0, 1])')
    parser.add_argument('M', type=int,
                        help='number of signals per value (must be odd)')
                    
    args = parser.parse_args()
    values = [ sympy.Rational(i, args.K)
               for i in xrange(1, args.K+1) ]
    game = MSignalAuction(values, args.M)
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   enumerator.EquilibriumList())
