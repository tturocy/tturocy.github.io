#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""Correlated private values, where correlation can be positive or negative.
Example referenced in Section 2 of the paper, but not given an example number.
"""

from sympy import Rational
import numpy

import auction
import enumerator

class CorrelatedPrivateValuesAuction(auction.InterdependentValuesAuction):
    def __init__(self, sigma):
        self.sigma = sigma
        auction.InterdependentValuesAuction.__init__(self)

    @property
    def signal_count(self):   return 2
    @property
    def signals(self):       return [ Rational(1,2), Rational(1) ]
        
    def _compute_h(self):
        h = numpy.zeros([ 2, 2 ], Rational)
        h[0,0] = self.sigma
        h[1,1] = self.sigma
        h[0,1] = 1-self.sigma
        h[1,0] = 1-self.sigma
        return h

    def _compute_V(self):
        V = numpy.zeros([ 2, 2 ], Rational)
        V[0,0] = Rational(1,2)
        V[0,1] = Rational(1,2)
        V[1,0] = Rational(1)
        V[1,1] = Rational(1)
        return V

if __name__ == "__main__":
    eqa = enumerator.EquilibriumList()

    # First: Independent private values.  KMS is satisfied; equilibrium is monotonic
    game = CorrelatedPrivateValuesAuction(Rational(1,2))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   eqa)

    # For the values we use (one-half and one), KMS is satisfied if
    # sigma is between 1/3 and 2/3.

    # Start right on the cusp: Here, (0,1) will be an admissible active set,
    # but in equilibrium on the corresponding interval 1 will not put any
    # probability mass.  So the equilibrium is still separating, but only
    # "weakly" so.
    game = CorrelatedPrivateValuesAuction(Rational(2,3))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   eqa)

    # Now move into the domain where KMS is no longer satisfied.
    game = CorrelatedPrivateValuesAuction(Rational(3,4))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   eqa)

    # But also remember that negative correlation is permitted.  Even with
    # mild negative correlation, we still have a monotonic equilibrium.
    game = CorrelatedPrivateValuesAuction(Rational(2,5))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   eqa)
    

    # Now, what if KMS is just barely satisfied
    game = CorrelatedPrivateValuesAuction(Rational(34,100))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game),
                                   eqa)

    # When KMS gets to 1/3, the active set at the top is (0,1)
    # but the equilibrium remains weakly separating
    game = CorrelatedPrivateValuesAuction(Rational(1,3))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game, (0,1)),
                                   eqa)
    
    # Now move into the domain where KMS is no longer satisfied.
    # Both types are active on the higher interval, and only the
    # lower type is active on the lower interval.
    game = CorrelatedPrivateValuesAuction(Rational(1,4))
    enumerator.enumerate_solutions(game,
                                   enumerator.PathEnumerator(game, (0,1)),
                                   eqa)
