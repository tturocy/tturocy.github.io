README for solver software package
Companion to "Two-bidder all-pay auctions with interdependent valuations,
including the highly competitive case" by Rentschler and Turocy, available
from http://www.gambit-project.org/turocy.

This version dated 5 June 2015.


This is a collection of scripts in Python which implement a toolkit for solving
the general case of two-bidder all-pay auctions with interdependent valuations
and private information, as described in the paper.

This software is Copyright (c) 2015 by Lucas Rentschler and Theodore L. Turocy.
This is free software, released under the terms of the GNU General Public License,
version 2 or (at your option) later.  See COPYING.txt for the full details.


PRELIMINARIES:

These scripts have been tested under Python 2.7.

These scripts make use of various third-party Python libraries, all of which
are available via the PyPI repository (installation via e.g. pip):

* networkx
* numpy
* scipy
* pydot
* sympy

MODULE auction.py

Terminology note: While we use 'type' in the paper, the term 'signal' is used
instead in the implementation, because 'type' has a special meaning in Python.

This module implements classes which represent the auction environment.
InterdependentValuesAuction is the base class, from which all the environments
are ultimately defined.

What this class expects is that derived classes will provide methods
_compute_h() and _compute_V() which construct and return the h and V matrices,
respectively, as defined in the paper.

In addition, there is an implementation of a ConditionalSignalsAuction, where
the types are independently determined conditional on a state of nature (e.g.,
a common value).  This expects the subclass to provide a function f() over
the state of nature, and g() defining the conditional probability of a type
given the state of nature, but then handles the computation of the h and V
matrices for you.


MODULE enumerator.py

This is the implementation of the algorithm.

The class AdmissibleSetGraph takes a game and constructs the graph of
admissible active sets.  The AdmissibleSetEnumerator iterates through all
possible subsets of signals and yields the ones for which a supporting
solution is found.

The function solve_path() takes a path of admissible active sets (called alpha in
the paper), constructs the equilibrium equations (5) and (6), and solves.
Here we make two notes.  First, although the supporting solution sets for each
active set can be pre-solved, in this implementation we do not take advantage
of this, as it is more transparent to see the whole set of equations, and we
have gone for clarity over optimization.  Similarly, we have chosen to implement
the equation solver symbolically using sympy.  This is also slightly inefficient,
as the system of equations is linear and therefore can naturally be represented
as a matrix and solved using linear algebra solvers, which would be faster.
Using the symbolic approach is convenient, however, because the case of there
being continuous sets of solutions is quite relevant in the games we consider
in the paper, and sympy expresses these in parametric form automatically.
The sympy package does use a linear solver for these systems, so the efficiency
loss is not too severe.

Finally, we have abstracted the process of traversing the graph into a PathEnumerator.
The number of paths can be quite large, and for specific applications one might want
to use certain heuristics to explore only certain types of paths, or to visit
paths in different orders.  The function enumerate_solutions() therefore takes
a path_enumerator as a parameter -- this can be any iterable object that returns
candidate paths.  We make use of this in the code for Example 5 to focus on specific
example paths, because the game has a cycle in the active set graph.

In addition to verbose textual output on the status of the search and on any equilibria
found, the support graphs, as shown in the paper, are generated for any equilibria
found, named eqm000.(eps,pdf), eqm001.(eps,pdf), and so on.


EXAMPLES

A total of eight example scripts are included with the package.

Each script exampleN.py, for N=1,2,3a,3b,4,5, corresponds to one of the six main
examples listed in the paper.  For the first five, parameters are passed on the
command line to specify the parameters of the model, as appropriate; calling
the script with the -h or --help switch lists which parameters there are.

Example 5 takes a slightly different approach.  As its objective is to explore this
game that has a cycle in its admissible active set graph, it sets out to illustrate the key
result in Corollary 6 that any equilibrium in which gap subpaths are traversed
more than once, implies an equilibrium with the same allocation of probability mass
and bid lengths to active sets, that traverses each gap subpath no more than once.
Therefore, the script manually calls out various paths with varying numbers of
traversals of the cycle to illustrate this.

The script Example 0 covers the unnumbered example, introduced at the end
of Section 2, which illustrates positively and negatively correlated private values.
This script also solves a series of games with different correlation parameters,
illustrating both that the equilibrium is monotonic when KMS is satisfied, while
also exhibiting equilibria in the cases where the values are too positively correlated,
and likewise too negatively correlated, to satisfy the condition.

Finally, example1-ext.py provides an extension of Example 1 in which any odd number
of types can be associated with each realized common value.  It is instructive
(and not too time consuming) to run the script for e.g. 4 values and 3 types per
value, and see that the broad pattern of diagonal bands of activity which occurs
in the two-type-per-value model continues to exist in this case.

