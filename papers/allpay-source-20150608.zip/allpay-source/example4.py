#
# Copyright (c) 2015, Lucas Rentschler (lrentschler@ufm.edu)
#                     Theodore L. Turocy (T.Turocy@uea.ac.uk)
#
# A utility for computing equilibria in two-bidder all-pay auctions
# with interdependent valuations
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
"""A correlated private values auction, where types are correlated into groups.
If signals are likely enough to be from the same group, bids may be
non-monotonic in the value of the prize conditional on one's own signal.
"""

import argparse

import numpy

import auction
import enumerator

class SignalClassAuction(auction.InterdependentValuesAuction):
    """Auction with K classes of pairs of types.  Conditional on having
    a particular type, the other bidder has probability 'p' of being each
    of the two types in the class, and (1-2p)/(2K-2) for each type outside
    the class.

    This setup also permits a generalized wallet-game structure, where the
    value is (1-gamma) * own type + gamma * other type.  Only the case
    gamma=0 (pure private values) is considered in the paper.
    """
    def __init__(self, K, p, gamma=0):
        self._values = [ auction.Rational(k+1, 2*K)
                         for k in xrange(2*K) ]
        self.K = K
        self.p = p
        self.gamma = gamma
        auction.InterdependentValuesAuction.__init__(self)
        
    @property
    def signal_count(self):   return len(self._values)
    @property
    def signals(self):        return self._values

    def _get_class(self, k):  return k / 2
        
    def _compute_h(self):
        h = numpy.zeros([ len(self._values), len(self._values) ],
                        auction.Rational)
        for (k, sk) in enumerate(self._values):
            for (ell, sl) in enumerate(self._values):
                if self._get_class(k) == self._get_class(ell):
                    h[ell,k] = self.p
                else:
                    h[ell,k] = auction.Rational(1-2*self.p, 2*(self.K-1))
        return h

    def _compute_V(self):
        V = numpy.zeros([ len(self._values), len(self._values) ],
                        auction.Rational)
        for (k, sk) in enumerate(self._values):
            for (ell, sl) in enumerate(self._values):
                V[k,ell] = (1-self.gamma)*sk + self.gamma*sl
        return V


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Solve Example 4 (private values with signal classes)')
    parser.add_argument('K', type=int,
                        help='number of classes (number of signals is 2*number of classes)')
    parser.add_argument('p', type=auction.Rational,
                        help='probability of each signal in same class')

    args = parser.parse_args()
    game = SignalClassAuction(K=args.K, p=args.p)
    eqa = enumerator.enumerate_solutions(game,
                                         enumerator.PathEnumerator(game),
                                         enumerator.EquilibriumList())

    
