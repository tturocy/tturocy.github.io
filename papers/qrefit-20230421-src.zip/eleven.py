"""Analysis of the 11-20 game by Arad and Rubenstein.
"""
import time

import numpy as np

import pcnojac
import pcjac


def f(x: np.array) -> np.array:
    expx = np.append(np.exp(x[:-1]), [0])
    lam = x[-1]
    fval = (
        np.array(
            [*[x[i + 1] - x[i] - lam * (1 + 20 * (expx[i + 2] - expx[i + 1]))
               for i in range(9)],
             expx.sum() - 1]
        )
    )
    return fval


def jac(x: np.array) -> np.array:
    # This allows us to pretend there's one additional higher strategy
    # at 21, but it's never played, simplifies maths
    expx = np.append(np.exp(x[:-1]), [0])
    lam = x[-1]
    ret = np.zeros((x.shape[0] - 1, x.shape[0]))
    for i in range(9):
        ret[i, i] = -1
        ret[i, i + 1] = 1 + 20 * lam * expx[i + 1]
        ret[i, i + 2] = -20 * lam * expx[i + 2]
        ret[i, -1] = -1 - 20 * (expx[i + 2] - expx[i + 1])
    # Conveniently adding the zero onto the probability vector happens
    # to give us the correct derivative for the sum equation!
    ret[-1] = expx
    return ret


def callback(x):
    point = np.exp(x[:-1])
    print(x[-1], point)


def main():
    print("Solving 11-20 game using Jacobian")
    x0 = np.array([np.log(0.1) for _ in range(10)])
    start = time.process_time()
    res = pcjac.solve_continuation(
        f,
        (0.0, 100.0),
        x0,
        jac,
        # callback=callback
    )
    print(
        f"Took {time.process_time() - start:.4f} for {res.nfev} function evaluations, {res.njev} Jacobian evaluations.")
    print(f"Computed {len(res.points)} points along curve.")
    print("Final point computed:")
    callback(res.points[-1])
    print()

    print("Solving 11-20 game by approximating Jacobian")
    x0 = np.array([np.log(0.1) for _ in range(10)])
    start = time.process_time()
    res = pcnojac.solve_continuation(
        f,
        (0.0, 100.0),
        x0,
        # callback=callback
    )
    print(f"Took {time.process_time() - start:.4f} for {res.nfev} function evaluations.")
    print(f"Computed {len(res.points)} points along curve.")
    print("Final point computed:")
    callback(res.points[-1])


if __name__ == "__main__":
    main()
