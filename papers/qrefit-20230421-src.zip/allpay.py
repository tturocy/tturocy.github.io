"""Compute QRE of two-player all-pay auction with private types,
following Rentschler and Turocy (in preparation).  Uses the idea
of Anderson et al. (1998) to structure the equations.
"""
import time

import numpy as np

import pcjac

# These are the parameters for the games the paper labeled Series 2 with p=0.9.
# Because this environment does not satisfy the Krishna-Morgan-Siegel condition for
# monotonicity, in equilibrium the two types randomize over partially-overlapping
# intervals.
phi = np.array([[1245, 405], [405, 2445]])
delta = 30


def sum_equation(profile: np.array, _logprofile: np.array,
                 _lam: float, signal: int) -> float:
    return profile[signal].sum() - 1.0


def sum_derivative(profile: np.array, _logprofile: np.array,
                   _lam: float, signal: int) -> np.array:
    deriv = np.zeros_like(profile)
    deriv[signal] = profile[signal]
    return np.pad(deriv.flatten(), (0, 1), 'constant')


def ratio_equation(profile: np.array, logprofile: np.array,
                   lam: float, signal: int, bid: int) -> float:
    return (
            logprofile[signal, bid + 1] - logprofile[signal, bid] -
            lam * (
                    0.5 * phi[signal, 0] * (profile[0, bid] + profile[0, bid + 1]) +
                    0.5 * phi[signal, 1] * (profile[1, bid] + profile[1, bid + 1]) -
                    delta
            )
    )


def ratio_derivative(profile: np.array, logprofile: np.array,
                     lam: float, signal: int, bid: int) -> np.array:
    deriv = np.zeros_like(profile)
    deriv[signal][bid] = (
            -1.0 - 0.5 * lam * phi[signal, signal] * profile[signal, bid]
    )
    deriv[signal][bid + 1] = (
            +1.0 - 0.5 * lam * phi[signal, signal] * profile[signal, bid + 1]
    )
    deriv[1 - signal][bid] = (
            -0.5 * lam * phi[signal, 1 - signal] * profile[1 - signal, bid]
    )
    deriv[1 - signal][bid + 1] = (
            -0.5 * lam * phi[signal, 1 - signal] * profile[1 - signal, bid + 1]
    )
    deriv = np.pad(deriv.flatten(), (0, 1), 'constant')
    deriv[-1] = -(
            0.5 * phi[signal, 0] * (profile[0, bid] + profile[0, bid + 1]) +
            0.5 * phi[signal, 1] * (profile[1, bid] + profile[1, bid + 1]) -
            delta
    )
    return deriv


def equations(x: np.array) -> np.array:
    lam = x[-1]
    logprofile = x[:-1].reshape([2, -1])
    profile = np.exp(logprofile)
    eqns = np.array(
        [sum_equation(profile, logprofile, lam, 0)] +
        [ratio_equation(profile, logprofile, lam, 0, bid)
         for bid in range(100)] +
        [sum_equation(profile, logprofile, lam, 1)] +
        [ratio_equation(profile, logprofile, lam, 1, bid)
         for bid in range(100)]
    )
    return eqns


def jacobian(x: np.array) -> np.array:
    lam = x[-1]
    logprofile = x[:-1].reshape([2, -1])
    profile = np.exp(logprofile)

    jac = np.array(
        [sum_derivative(profile, logprofile, lam, 0)] +
        [ratio_derivative(profile, logprofile, lam, 0, bid)
         for bid in range(100)] +
        [sum_derivative(profile, logprofile, lam, 1)] +
        [ratio_derivative(profile, logprofile, lam, 1, bid)
         for bid in range(100)]
    )
    return jac


def jacobian_numerical(x: np.array) -> np.array:
    """This is a naive implementation of the Jacobian using
    forward differences, used to approximate the benefits of
    the hand-crafted Jacobian function in this application.
    """
    h = .01
    b = np.zeros((len(x), len(x) - 1))
    n1, _ = b.shape
    for i in range(n1):
        x[i] += h
        b[i, :] = equations(x)
        x[i] -= h
    y = equations(x)
    for i in range(n1):
        b[i, :] = (b[i, :] - y[:]) / h
    return b.transpose()


def callback(x):
    lam = x[-1]
    profile = np.exp(x[:-1].reshape([2, -1]))
    print(lam)
    print(profile)


def solve():
    print("Solving all-pay auction with two types using hand-crafted Jacobian.")
    x0 = np.array([np.log(1.0 / 101.0) for _ in range(202)])
    start = time.process_time()
    res = pcjac.solve_continuation(
        equations,
        (0.0, 100.0),
        x0,
        jacobian,
        # callback=callback
    )
    print(
        f"Took {time.process_time() - start:.4f} for {res.nfev} function evaluations, {res.njev} Jacobian evaluations.")
    print(f"Computed {len(res.points)} points along curve.")
    print("Final point computed:")
    callback(res.points[-1])
    print()

    print("Solving all-pay auction with two types using generic Jacobian.")
    x0 = np.array([np.log(1.0 / 101.0) for _ in range(202)])
    start = time.process_time()
    res = pcjac.solve_continuation(
        equations,
        (0.0, 100.0),
        x0,
        jacobian_numerical,
        # callback=callback
    )
    print(
        f"Took {time.process_time() - start:.4f} for {res.nfev} function evaluations, {res.njev} Jacobian evaluations.")
    print(f"Computed {len(res.points)} points along curve.")
    print("Final point computed:")
    callback(res.points[-1])


if __name__ == "__main__":
    solve()
