"""Python implementation of predictor-corrector continuation method
using Broyden updates to approximate Jacobian of the system.
Based on Program 3 from Allgower and Georg.
"""

# Program 3 from Allgower and Georg does not seem to work "out of the
# box", even on the sample problem included in the book.  There are
# a few irregularities in the program, such as unused parameters, which
# makes one a bit suspicious of the code as written.
#
# In the below, we have made the following changes/adjustments to the
# code.
#
# (1) In the Newton step updating, the implementation of the 
# update of the QR decomposition in (their) line 95/96 is suspicious.
# The update uses only the value of the map at the corrector - whereas
# the math in Chapter 7 suggests the value of the map should be dotted
# into the direction (corrector - predictor).  Without this multiplication,
# problems which are isomorphic up to the sign of the function give
# different results - often with the program running well on one statement
# but failing when the sense of some components of the map are
# changed.

# (2) We have also found that the orientation of the curve matters.
# The code as provided appears to work for positively-oriented curves,
# but (sometimes) fails on an equivalent problem with a negatively-oriented
# curve.  Flipping the sign of one component of the map flips the
# sense of the curve, so internally we wrap the map function such that
# the sign of the first component is flipped if needed to generate
# a positive orientation.  We are somewhat less certain where/why this
# is the case, but we believe it is in the updating of the Jacobian at the
# predictor step, where the orientation should matter.
#
# (3) We also implement a fallback where the Jacobian is re-initialised
# via first differences, should the tracing run into trouble.


import math
import typing

import numpy as np


def jac(fun, x, h):
    """x: input, b: output.
    Evaluates the transpose 'b' of the Jacobian at x
    by using forward differences.
    """
    b = np.zeros((len(x), len(x) - 1))
    n1, _ = b.shape
    for i in range(n1):
        x[i] += h
        b[i, :] = fun(x)
        x[i] -= h
    y = fun(x)
    for i in range(n1):
        b[i, :] = (b[i, :] - y[:]) / h
    return b


def givens(b, q, c1, c2, ell1, ell2, ell3):
    """
    input: b, q, c1, c2, ell1, ell2, ell3
    output: b, q, c1, c2
    one Givens rotation is performed
    on rows ell1 and ell2 or b and q
    the rotation maps c1, c2 onto sqrt(c1**2, c2**2), 0
    """
    n1, n = b.shape
    if abs(c1) + abs(c2) == 0.0:
        return c1, c2
    if abs(c2) > abs(c1):
        sn = math.sqrt(1.0 + (c1 / c2) ** 2) * abs(c2)
    else:
        sn = math.sqrt(1.0 + (c2 / c1) ** 2) * abs(c1)
    s1 = c1 / sn
    s2 = c2 / sn
    for k in range(n1):
        sv1 = q[ell1, k]
        sv2 = q[ell2, k]
        q[ell1, k] = s1 * sv1 + s2 * sv2
        q[ell2, k] = -s2 * sv1 + s1 * sv2
    for k in range(ell3, n):
        sv1 = b[ell1, k]
        sv2 = b[ell2, k]
        b[ell1, k] = s1 * sv1 + s2 * sv2
        b[ell2, k] = -s2 * sv1 + s1 * sv2
    return sn, 0


def qr_decomp(b: np.array) -> typing.Tuple[np.array, np.array]:
    """
    input: b, output: b, q, cond
    a QR decomposition for b in stored in q, b
    by using Givens rotations on b and q = id
    until b is upper triangular
    """
    n1, n = b.shape
    # Start with q = identity
    q = np.identity(n1)
    for m in range(n):
        for k in range(m + 1, n1):
            b[m, m], b[k, m] = givens(b, q, b[m, m], b[k, m], m, k, m + 1)
    return b, q


def condition(b: np.array) -> float:
    """Compute the condition number of 'b'."""
    n = b.shape[1]
    cond = 0.0
    for i in range(1, n):
        for k in range(i - 1):
            cond = max(cond, abs(b[k, i] / b[i, i]))
    return cond


def upd(q, b, _x, _u, y, w, t, h, _omega):
    """
    input: q, b, x, u = predictor, y=H(x), w=H(u)
    q, b = QR decomposition of transpose(H')
    q, b are updated
    perturbations are used for stabilisation
    an angle test is performed
    """
    # Maximal angle
    angmax = math.pi / 3

    n1, n = b.shape
    for k in range(n):
        b[n1 - 1, k] = (w[k] - y[k]) / h
    for k in range(n):
        b[k, k], b[n1 - 1, k] = givens(b, q, b[k, k], b[n1 - 1, k], k, n1 - 1, k)
    ang = 0
    for k in range(n1):
        ang += t[k] * q[n1 - 1, k]
    if ang > 1.0:
        ang = 1.0
    if ang < -1.0:
        ang = -1.0
    return math.acos(ang) <= angmax


def ynorm(y):
    s = 0
    for k in range(len(y)):
        s += y[k] ** 2
    return math.sqrt(s)


def newt(fun, q, b, u, v, w, r, dmax, dmin,
         ctmax, cdmax, _omega):
    """
    input q, b, u, w = H(u)
    output v, r = H(v), returns test
    w is changed
    one Newton step v = u - A^+ w is performed
    where A \approx H'
    q, b = QR decomposition of A*
    q, b are updated
    perturbations are used for stabilisation
    residual and contraction tests are performed
    """
    n1, n = b.shape
    test = True

    # Perturbation
    pert = .00001
    pv = np.zeros(n)
    for k in range(n):
        if abs(w[k]) > pert:
            pv[k] = 0
        elif w[k] > 0:
            pv[k] = w[k] - pert
        else:
            pv[k] = w[k] + pert
    w -= pv

    d1 = ynorm(w)
    if d1 > dmax:
        # print("Norm test failed.")
        return False
    for k in range(n):
        for ell in range(k - 1):
            w[k] = w[k] - b[ell, k] * w[ell]
        w[k] = w[k] / b[k, k]
    # d2 = ynorm(w)
    for k in range(n1):
        s = 0.0
        for ell in range(n):
            s = s + q[ell, k] * w[ell]
        v[k] = u[k] - s
    np.copyto(r, fun(v))
    p = r - pv
    d3 = ynorm(p)
    contr = d3 / (d1 + dmin)
    if contr > ctmax:
        # print(f"Contraction test failed: {contr}")
        test = False
    for k in reversed(range(0, n - 1)):
        w[k], w[k + 1] = givens(b, q, w[k], w[k + 1], k, k + 1, k)
    for k in range(n):
        # In the original this says
        # b[0, k] = b[0, k] - p[k] / d2
        # Based on the exposition in Chapter 7 it looks like the below
        # is more correct.  (?)
        b[0, k] = b[0, k] - p[k] * (v[k] - u[k]) / ynorm(v - u)
    for k in range(n - 1):
        b[k, k], b[k + 1, k] = givens(b, q, b[k, k], b[k + 1, k], k, k + 1, k)
    if b[n - 1, n - 1] < 0:
        # print("Orientation test failed")
        test = False
        b[n - 1, n - 1] = -b[n - 1, n - 1]
        for k in range(n1):
            q[n - 1, k] = -q[n - 1, k]
            q[n1 - 1, k] = -q[n1 - 1, k]
    # Perturbation of upper triangular matrix
    for i in range(1, n):
        for k in range(i - 1):
            if abs(b[k, i]) > cdmax * abs(b[i, i]):
                if b[i, i] > 0:
                    b[i, i] = abs(b[k, i]) / cdmax
                else:
                    b[i, i] = -abs(b[k, i]) / cdmax
    for k in range(n - 1):
        b[k + 1, k] = 0
    return test


class Bunch:
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)


def solve_continuation(
        fun,
        t_span,
        x0,
        first_step=0.01,
        min_step=.000001,
        callback=None,
) -> Bunch:
    """
    Solve a parameterized system of equations by numerical continuation.
    An initial value of the Jacobian is computed using numerical differentiation,
    and on each step is updated using a Broyden-like method.

    Parameters
    ----------
    fun : callable
        Left-hand side of the system.  Calling signature is
        ``fun(x)``, where `x` has shape (n+1,), consisting of the
        n variables of the system followed by the parameter.

    t_span : 2-tuple of floats
        Interval of solution (t0, tf).  The solver starts at t=t0
        and traces a path until it reaches a solution with parameter
        outside of (t0, tf).

    x0 : array_like, shape (n,)
        Initial solution value valid at the first element of `t_span`.

    first_step : float, optional
        Initial stepsize

    min_step : float, optional
        Minimum allowed step size.  If the step size falls below this
        length, the tracing terminates.

    callback : callable, optional
        Function to call after each step.  The signature is `callback(xk)`,
        where `xk` is the accepted point.

    Returns
    -------
    Bunch object with the following fields defined:

    points : list
        Points computed along the parameterized curve.
    nfev : int
        Number of evaluations of the left-hand side.
    message : string
        Human-readable description of the termination reason.
    success : bool
        True if the solver reached the end of the interval.
    """
    # Maximal contraction rate in corrector
    max_contr = .8
    # Maximal norm for H
    dmax = .2
    # Minimal norm for H
    dmin = .001
    # Maximal stepsize
    hmax = 1.28
    # Minimal Newton stepsize
    # hmn = .00001
    # Stepsize
    h = first_step
    # Maximum for condition estimate
    cdmax = 1000.0
    # Acceleration factor for steplength control
    acfac = 1.01

    def wrapfun(arg): return signvec * fun(arg)

    # Dimensions - should be able to remove this
    n1 = len(x0) + 1
    n = n1 - 1

    x = np.append(x0, t_span[0])
    y = np.zeros(n)
    b, q = qr_decomp(jac(fun, x, h=.01))
    # This provides a very coarse condition number
    if condition(b) >= cdmax:
        print("Bad condition estimate at initial point.")
        return Bunch(nfev=0, points=[x])

    # Last column of 'q' is the tangent vector.
    # This determines the orientation of the tracing along the curve, based
    # on the sign of the parameter in the tangent vector.
    omega = 1.0 if q[-1, -1] > 0 else -1.0
    # print(f"Orientation of the curve is {omega}")
    signvec = np.ones_like(x0)
    if omega < 0.0:
        signvec[0] = -1.0
    b, q = qr_decomp(jac(wrapfun, x, h=.01))
    # With the wrapped function orientation is positive
    omega = 1.0

    bunch = Bunch(nfev=n1 + 1, points=[x])

    # The PC loop
    while min(t_span) <= x[-1] <= max(t_span):
        if abs(h) <= min_step:
            # Stepsize below minimum tolerance; terminate.
            bunch.success = False
            bunch.message = f"Stepsize {abs(h)} less than minimum {min_step}."
            return bunch

        # Save tangent
        t = q[-1, :].copy()
        # Predictor step
        u = x + h * omega * t
        w = wrapfun(u)
        bunch.nfev += 1
        test = upd(q, b, x, u, y, w, t, h, omega)
        if not test:
            # Angle test is negative
            # print("Angle test is negative")
            h /= acfac
            continue

        r = np.zeros(n)
        v = np.zeros(n1)
        test = newt(wrapfun, q, b, u, v, w, r, dmax, dmin,
                    max_contr, cdmax, omega)
        # There is a function evaluation inside `newt`
        bunch.nfev += 1
        if not test:
            # Residual or contraction test is negative
            h /= acfac
            b, q = qr_decomp(jac(wrapfun, u, h=.01))
            continue
        # PC step accepted
        # TODO: Newton steplength if we want to compute endpoint exactly
        # or implement criterion function
        h = abs(h) * acfac
        # Move to next point; adapt steplength
        x, y, h = v, r, min(h, hmax)
        bunch.points.append(x)
        if callback:
            callback(x)

    bunch.success = True
    bunch.message = "Computation completed successfully."
    return bunch
