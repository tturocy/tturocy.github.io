# Predictor-corrector methods for computing logit QRE

The programs in this folder are companion materials to

    Bland, James and Turocy, Theodore.  *Quantal response equilibrium as
    structural model for estimation: The missing manual*

Included are two functions which implement predictor-corrector methods:

* `pcjac.solve_continuation`, which requires a function computing the
  Jacobian of the system of equations;
* `pcnojac.solve_continuation`, which approximates the Jacobian initially
  via numerical differentation and then subsequently does an update of
  the estimated Jacobian at each step.

These implementations have been instrumented and documented to be similar in
usage to similar functions in scipy implementing the solution of differential
equations.

The programs have been developed and tested using numpy 1.24.2 and scipy 1.10.1.

We provide implementations which compute the LQRE correspondence for two games
mentioned in the paper, comparing the performance of the `pcjac` and
`pcnojac` versions.

* `ochs.py` computes the correspondence for the Ochs asymmetric matching pennies game.
* `eleven.py` computes the correspondence for the 11-20 demand game of Arad and Rubenstein.

The driver programs report the number of function (and for `pcjac`, Jacobian) evaluations,
and the process time elapsed in tracing the curve, as well as the final point computed.

In addition, we provide an example of a two-player all-pay auction game with two types
and 100 bids, based on the games played in Rentschler and Turocy (working paper) which
in turn are derived from the more general two-player all-pay auction from Rentschler and
Turocy (2015, JET).  In this example, we compare the performance of the `pcjac`
version with a hand-coded Jacobian versus one in which the Jacobian is computed numerically
using forward differences.  In this game, the function computing equation values for H
*does* take advantage of the structure of the game, so this helps to illustrate
the usefulness of investing in coding the Jacobian as well.

The provided programs are useful for comparing qualitatively the performance of the methods
illustrated.  As they are written in Python, and do not make full use of vectorization of
operations in numpy and scipy, they are in absolute terms much slower than optimized
implementations in a compiled language.  They are structured to promote readability
first.