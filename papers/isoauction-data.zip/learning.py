#
# This program reads in the raw CSV data and identifies pairs of periods in
# which a subject received the same value.
#

import string
import csv

def flatten(L):
    if not isinstance(L,list): return [L]
    if L == []: return L
    return flatten(L[0]) + flatten(L[1:])

def entries(L):
    """
    Returns a list of the unique entries in list L
    """
    d = { }
    for entry in L: d[entry] = 1
    return d.keys()

def Numericalize(data):
    """
    Clean up data to be numerical, as appropriate
    """
    for x in data:
        for key in [ "period", "group", "subject", "value",
                     "bid", "won", "earnings" ]:
            x[key] = int(x[key])


def Directional(data, f):
    sessions = entries([x["session"] for x in data])

    f.write("session,type,subject,value,period1,group1,bid1,won,period2,group2,bid2\n")

    for ses in sessions:
        for bidder in range(18):
            subdata = filter(lambda x:
                             x["session"] == ses and x["subject"] == bidder,
                             data)
            subdata.sort(lambda x, y: cmp("%03d%02d" % (x["value"],
                                                        x["period"]),
                                          "%03d%02d" % (y["value"],
                                                        y["period"])))

            up = 0
            same = 0
            down = 0
            
            for i in range(len(subdata)-1):
                e1 = subdata[i]
                e2 = subdata[i+1]

                if e1["value"] == e2["value"]:
                    # Print out a record.
                    f.write("%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d\n" %
                            (ses, e1["type"], bidder, e1["value"],
                             e1["period"], e1["group"], e1["bid"], e1["won"],
                             e2["period"], e2["group"], e2["bid"]))

if __name__ == '__main__':
    import sys
    data = [ line for line in csv.DictReader(file("alldata.csv")) ]
    Numericalize(data)
    Directional(data, file("learning.csv", "w"))

