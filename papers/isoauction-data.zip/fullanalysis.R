#
# Program to do the full analysis of the isoauction data
#

#
# Preliminary function definitions
#

# OLS with White standard errors
summaryw <- function( model) {
  s <- summary( model)
  X <- model.matrix( model)
  u2 <- residuals( model)^2
  XDX <- 0
  ## here one needs essentially to calculate X'DX.  But due to the fact that D
  ## is huge (NxN), it is better to do it with a cycle.
  for( i in 1:nrow( X)) {
    XDX <- XDX + u2[i]*X[i,]%*%t( X[i,])
  }
  XX1 <- solve( t( X)%*%X)
  varcovar <- XX1 %*% XDX %*% XX1
  stdh <- sqrt( diag( varcovar))
  t <- model$coefficients/stdh
  p <- 2*pnorm( -abs( t))
  results <- cbind( model$coefficients, stdh, t, p)
  dimnames(results) <- dimnames( s$coefficients)
  results
}

#
# End of preliminaries
#


#
# Read in data and do initial aggregations
#

subjects <- read.table("alldata.csv", header=TRUE, sep=",")

# Aggregate the data into market level.  Creates frame with two pieces
# of data on each market: the market price (market) and the maximum
# private value in the market (maxval).
markets <- aggregate(list(market=subjects$bid,maxval=subjects$value,
                          winval=subjects$value*subjects$won), 
                     list(session=subjects$session, type=subjects$type,
                          period=subjects$period, group=subjects$group), 
                     max)

# Need to convert periods and groups back into numeric data
markets$period <- as.integer(as.character(markets$period))
markets$group <- as.integer(as.character(markets$group))
markets$cohort <- as.integer(markets$group <= 2)

# Assign an identifier per session-cohort 
markets$sescoh <- paste(markets$session, markets$cohort, sep=".")

# Compute the theory price
markets$theory <- markets$maxval * 2/3

# Identify which market prices were individually rational
markets$rational <- markets$market < markets$maxval

# Divide periods into four quarters
markets$quarter <- 0
markets$quarter[markets$period<=15] <- 1
markets$quarter[markets$period>15&markets$period<=30] <- 2
markets$quarter[markets$period>30&markets$period<=45] <- 3
markets$quarter[markets$period>45&markets$period<=60] <- 4


#
# End of initializations
#



#
# For Result 0
# Compare individual market results against the RNNE prediction
#
attach(markets)
for (mkttype in levels(type)) {
  print(mkttype)
  print(summary(market[type==mkttype] > 2/3*maxval[type==mkttype]))
  print(summary(market[type==mkttype] == 2/3*maxval[type==mkttype]))
  print(summary(market[type==mkttype] < 2/3*maxval[type==mkttype]))
}
detach(markets)
#
# End Result 0
#

#
# For Result 1
# Compare median prices against each other
#

# Entire session
medians <- aggregate(list(med=markets$market, maxval=markets$maxval),
                     list(type=markets$type,
                          period=markets$period, group=markets$group),
                     median)

usmedians <- unstack(medians, med~type)
attach(usmedians)
table(cut(sign(sealed - dutch), breaks=c(-2,-1,0,1)))
table(cut(sign(sealed - silent), breaks=c(-2,-1,0,1)))
table(cut(sign(silent - dutch), breaks=c(-2,-1,0,1)))
detach(usmedians)

# First 30 periods 
submedians <- aggregate(list(med=markets$market[markets$period<=30], 
                             maxval=markets$maxval[markets$period<=30]),
                        list(type=markets$type[markets$period<=30],
                             period=markets$period[markets$period<=30], 
                             group=markets$group[markets$period<=30]),
                        median)

usmedians <- unstack(submedians, med~type)
attach(usmedians)
table(cut(sign(sealed - dutch), breaks=c(-2,-1,0,1)))
table(cut(sign(sealed - silent), breaks=c(-2,-1,0,1)))
table(cut(sign(silent - dutch), breaks=c(-2,-1,0,1)))
detach(usmedians)

# Last 30 periods 
submedians <- aggregate(list(med=markets$market[markets$period>30], 
                             maxval=markets$maxval[markets$period>30]),
                        list(type=markets$type[markets$period>30],
                             period=markets$period[markets$period>30], 
                             group=markets$group[markets$period>30]),
                        median)

usmedians <- unstack(submedians, med~type)
attach(usmedians)
table(cut(sign(sealed - dutch), breaks=c(-2,-1,0,1)))
table(cut(sign(sealed - silent), breaks=c(-2,-1,0,1)))
table(cut(sign(silent - dutch), breaks=c(-2,-1,0,1)))
detach(usmedians)

#
# End Result 1
#

#
# For Result 2
# Time trends of market prices, by cohort
#
for (ses in levels(as.factor(markets$sescoh))) {
  print(ses)
  subframe <- data.frame(period=markets$period[markets$sescoh==ses&markets$rational],
                         theory=markets$theory[markets$sescoh==ses&markets$rational],
                         market=markets$market[markets$sescoh==ses&markets$rational])
  attach(subframe)
  model <- lm(market~0+theory+theory:period)
  print(summary(model))
  print(summaryw(model))
  detach(subframe)
}

for (t in levels(markets$type)) {
  print(t)
  subframe <- data.frame(period=markets$period[markets$type==t&markets$rational],
                         theory=markets$theory[markets$type==t&markets$rational],
                         market=markets$market[markets$type==t&markets$rational])
  attach(subframe)
  model <- lm(market~0+theory+theory:period)
  print(summary(model))
  print(summaryw(model))
  detach(subframe)
}

#
# End Result 2
#


#
# For Result 3
# Efficiency of allocation
#

alloceff <- aggregate(list(alloc=as.integer(markets$maxval==markets$winval)),
                      list(type=markets$type), sum)
print(alloceff)

alloceff <- aggregate(list(alloc=as.integer(markets$maxval==markets$winval)),
                      list(type=markets$type, quarter=markets$quarter),
                      sum)
print(alloceff)

#
# Hypothesis testing: are sealed and dutch frequencies of allocation the same
# by quarter?
#
for (quarter in 1:4)  {
  print(prop.test(c(sum(as.integer(markets$maxval==markets$winval)[markets$type=="dutch"&markets$quarter==quarter]),
              sum(as.integer(markets$maxval==markets$winval)[markets$type=="sealed"&markets$quarter==quarter])),
            c(270,270)))
}


pcteff <- aggregate(list(pct=markets$winval/markets$maxval),
                    list(type=markets$type), mean)
print(pcteff)

pcteff <- aggregate(list(sdpct=markets$winval/markets$maxval),
                    list(type=markets$type), sd)
print(pcteff)

pcteff <- aggregate(list(pct=markets$winval/markets$maxval),
                    list(type=markets$type, quarter=markets$quarter), mean)
print(pcteff)

pcteff <- aggregate(list(sdpct=markets$winval/markets$maxval),
                    list(type=markets$type, quarter=markets$quarter), sd)
print(pcteff)

#
# Hypothesis testing: are sealed and dutch percentage efficiencies the same
# by quarter?
#
for (quarter in 1:4)  {
  print(t.test((markets$winval/markets$maxval)[markets$type=="dutch"&markets$quarter==quarter],
               (markets$winval/markets$maxval)[markets$type=="sealed"&markets$quarter==quarter]))
}

#
# End Result 3
#

#
# For Result 4
# Subject earnings
#

earnings <- aggregate(list(earnings=subjects$earnings),
                      list(session=subjects$session, type=subjects$type,
                           subject=subjects$subject),
		      sum)
for (t in levels(earnings$type)) {
  print(t)
  print(summary(earnings$earnings[earnings$type == t]))
}

#
# End Result 4
#


#
# Interlude: Load in and process data for learning/adaptation results
#

learning <- read.table("learning.csv", header=TRUE, sep=",")

# We augment this data by matching in the market prices
# I can't help but suspect there's a better way, but this works.
for (i in 1:length(learning$bid1))  {
  learning$market1[i] = max(markets$market[markets$session==learning$session[i]&
					   markets$period==learning$period1[i]&
                                           markets$group==learning$group1[i]])
  learning$market2[i] = max(markets$market[markets$session==learning$session[i]&
					   markets$period==learning$period2[i]&
                                           markets$group==learning$group2[i]])
}

#
# End of Interlude
#

#
# For Result 5
# Directional learning
#

afterwin <- learning[learning$won==1 & learning$period1+1==learning$period2,
               	     c("session", "type", "subject", "bid1", "bid2")]

for (t in levels(afterwin$type)) {
  print(t)
  print(table(cut(sign(afterwin$bid1[afterwin$type==t&afterwin$bid2>-1] - 
                       afterwin$bid2[afterwin$type==t&afterwin$bid2>-1]), 
                  breaks=c(-2,-1,0,1))))
}

# Special case: how many times did a bidder win a Dutch auction, but 
# did not win the second time, while the market price exceeded the
# first market price?

dutchwin <- learning[learning$won==1 & learning$period1+1==learning$period2 &
                     learning$bid2==-1 & learning$market2>learning$market1+10,
	             c("session", "type", "subject", "bid1", "market1", "bid2", "market2")]
print(dutchwin)

afterloss <- learning[learning$won==0 & learning$bid1>0 &
                      learning$period1+1==learning$period2 &
                      learning$market1<learning$value,
                      c("session", "type", "subject", "bid1", "bid2")]
for (t in levels(afterloss$type)) {
  print(t)
  print(table(cut(sign(afterloss$bid1[afterloss$type==t&afterloss$bid2>-1] - 
                       afterloss$bid2[afterloss$type==t&afterloss$bid2>-1]), 
                  breaks=c(-2,-1,0,1))))
}

#
# End Result 5
#

#
# For Result 6
# Longer-term adaptation of behavior
#

adaptpair <- learning[learning$period1+25>learning$period2 &
                      learning$value >= 300,
                      c("session", "type", "subject", "bid1", "bid2")]

adapt <- aggregate(list(increase=as.integer(adaptpair$bid2>adaptpair$bid1),
                        same=as.integer(adaptpair$bid2==adaptpair$bid1),
                        decrease=as.integer(adaptpair$bid2<adaptpair$bid1)),
                   list(session=adaptpair$session, type=adaptpair$type,
                        subject=adaptpair$subject),
                   sum)
print(adapt)
attach(adapt)
uppct <- increase/(increase+same+decrease)
samepct <- same/(increase+same+decrease)
downpct <- decrease/(increase+same+decrease)

print(aggregate(list(decreasers=as.integer(downpct>uppct),
                     increasers=as.integer(uppct>downpct),
                     equals=as.integer(downpct==uppct)),
                list(type=type),
                sum))

#
# Check: does the inertia of the sealed implementation first-order
# stochastically dominate that of the silent?
#
print(sort(samepct[type=="sealed"])-sort(samepct[type=="silent"]))

# baryplot is from http://arbeit.ucdavis.edu/mcelreath/baryplot.html
library(baryplot)

postscript("learning.eps", horizontal=FALSE, width=5, height=8, onefile=FALSE)
par(mfcol=c(2,1))

bary.init()
title("Sealed implementation")
bary.labels("Decrease", "No change", "Increase")

for (i in 1:54) {
  bary.point(c(downpct[type=="sealed"][i], samepct[type=="sealed"][i]), pch=15)
}

bary.line(c(1/2,0), c(0,1), arrow=FALSE)


bary.init()
title("Silent implementation")
bary.labels("Decrease", "No change", "Increase")

for (i in 1:54) {
  bary.point(c(downpct[type=="silent"][i], samepct[type=="silent"][i]), pch=15)
}

bary.line(c(1/2,0), c(0,1), arrow=FALSE)

detach(adapt)

