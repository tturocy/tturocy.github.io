#
# Compute risk-neutral Nash equilibrium earnings
#

import string
#import Gnuplot
import csv

def flatten(L):
    if not isinstance(L,list): return [L]
    if L == []: return L
    return flatten(L[0]) + flatten(L[1:])

def entries(L):
    """
    Returns a list of the unique entries in list L
    """
    d = { }
    for entry in L: d[entry] = 1
    return d.keys()

def Numericalize(data):
    """
    Clean up data to be numerical, as appropriate
    """
    for x in data:
        for key in [ "period", "group", "subject", "value",
                     "bid", "won", "earnings" ]:
            x[key] = int(x[key])


def ComputeDerivedData(data):
    """
    Compute 'derived' data (theory prices, efficiency, etc.)
    """
    sessions = entries([x["session"] for x in data])

    #print "session,sealed,silent,dutch,period,group,market,theory"
    for ses in sessions:
        for period in xrange(1, 61):
            for group in range(6):
                subdata = [ x for x in data if
                            x["session"] == ses and
                            x["period"] == period and
                            x["group"] == group ]
                for entry in subdata:
                    entry["theorybid"] = entry["value"]*2/3
                    
                maxval = max([x["value"] for x in subdata])
                theory = max([x["value"]*2/3 for x in subdata])

                market = max([x["theorybid"] for x in subdata])
                winners = [x for x in subdata if x["theorybid"] == market]

                for entry in subdata:
                    entry["theoryearnings"] = 0
                for entry in winners:
                    entry["theoryearnings"] = (entry["value"] - entry["theorybid"]) / float(len(winners))
                

if __name__ == '__main__':
    import sys
    data = [ line for line in csv.DictReader(file(sys.argv[1])) ]
    Numericalize(data)
    ComputeDerivedData(data)

    # All sessions have identical values, so just look at one
    subdata = [ x for x in data if x["session"] == "S20041201" ]

    print "subject,earnings"
    for subj in xrange(18):
        subjdata = [x for x in subdata if x["subject"] == subj ]
        print "%d,%d" % (subj, sum([x["theoryearnings"] for x in subjdata]))
    
