import random

def winner(x):
    """
    Compute the winner of the auction, breaking ties randomly if
    necessary.
    """
    mv = max(x)
    # There must be a more Pythonic way to do this, butohwell...
    winners = [ ]
    for (i,entry) in enumerate(x):
        if entry == mv:
            winners.append(i)
            
    return random.choice(winners)

#
# Simulate an auction by drawing N values from 'values', simulating the
# ZI bids for those values, and returning a tuple containing the
# percentage efficiency and an indicator variable for efficient allocation
#
def simauction(N, values, bids):
    v = [ random.choice(values) for i in range(N) ]

    # We need to use x <= entry instead of x < entry for the Cox et al treatment
    b = [ random.choice([x for x in bids if x <= entry])
          for entry in v ]

    mv = max(v)
    w = winner(b)
    return ( float(v[w]) / float(mv), int(v[w] == mv) ) 


def eff(N, K, values, bids):
    pct = 0
    count = 0
    pcts = [ ]

    for it in range(K):
        result = simauction(N, values, bids)
        pct += result[0]
        count += result[1]
        pcts.append(result[0])

    import stats
    print stats.mean(pcts), stats.stdev(pcts)

    return ( pct / float(K), float(count) / float(K) )


#
# Simulate an auction where the bidders have values in 'values'.
# Simluate ZI bids for those values, and returning a tuple containing the
# percentage efficiency and an indicator variable for efficient allocation
#
def simperiod(values, bids):
    b = [ random.choice([x for x in bids if x <= entry])
          for entry in values ]

    mv = max(values)
    w = winner(b)
    return ( float(values[w]) / float(mv), int(values[w] == mv) ) 

#
# Simulate the sequence of realized values in 'valuelist' K times
# with 'bids' being the valid bids, and return a tuple containing
# the average percentage efficiency and the frequency of efficient allocation
#
def simsession(K, valuelist, bids):
    pct = 0
    count = 0
    pcts = [ ]

    for it in range(K):
        for values in valuelist:
            result = simperiod(values, bids)
            pct += result[0]
            count += result[1]
            pcts.append(result[0])

    import stats
    print stats.mean(pcts), stats.stdev(pcts)

    return ( pct / float(K*len(valuelist)), float(count) / float(K*len(valuelist)) )


def simcontauction(N):
    v = [ random.uniform(0, 1) for i in range(N) ]

    b = [ random.uniform(0, entry) for entry in v ]

    mv = max(v)
    w = winner(b)
    return ( float(v[w]) / float(mv), int(v[w] == mv) ) 

def conteff(N, K):
    pct = 0
    count = 0
    pcts = [ ]

    for it in range(K):
        result = simcontauction(N)
        pct += result[0]
        count += result[1]
        pcts.append(result[0])

    import stats
    print stats.mean(pcts), stats.stdev(pcts)

    return ( pct / float(K), float(count) / float(K) )

K = 1000000

import csv
data = [ line for line in csv.DictReader(file("values.csv")) ]

print "For our actual realizations of private values:"
print "-----------------------------------------------"

results = simsession(K / len(data),
                     [ [ int(x["v1"]), int(x["v2"]), int(x["v3"]) ]
                       for x in data ],
                     [ x * 10 for x in range(1, 63) ])

print "Percentage of gains extracted: %f" % results[0]
print "Frequency of efficient allocation: %f" % results[1]
print


for (qtr,r) in enumerate([xrange(1, 16), xrange(16, 31),
                          xrange(31, 46), xrange(46, 61)]):
    print "For our actual realizations, quarter %d" % (qtr+1)
    print "--------------------------------------"

    subdata = [ [ int(x["v1"]), int(x["v2"]), int(x["v3"]) ]
                for x in data if int(x["period"]) in r ]
    results = simsession(K / len(subdata),
                         subdata, [ x * 10 for x in range(1, 63) ])

    print "Percentage of gains extracted: %f" % results[0]
    print "Frequency of efficient allocation: %f" % results[1]
    print


print "For our environment:"
print "--------------------"

results = eff(3, K,
              [ x * 15 for x in range(1, 41) ],
              [ x * 10 for x in range(1, 63) ])

print "Percentage of gains extracted: %f" % results[0]
print "Frequency of efficient allocation: %f" % results[1]
print

print "For our environment with 1/2 the types and bids:"
print "------------------------------------------------"

results = eff(3, K,
              [ x * 15 for x in range(1, 21) ],
              [ x * 10 for x in range(1, 32) ])

print "Percentage of gains extracted: %f" % results[0]
print "Frequency of efficient allocation: %f" % results[1]
print


print "For Cox et al environment:"
print "--------------------------"

results = eff(3, K,
              [ 10 + x * 40 for x in range(0, 43) ],
              [ 10 + x * 40 for x in range(0, 45) ])

print "Percentage of gains extracted: %f" % results[0]
print "Frequency of efficient allocation: %f" % results[1]
print

print "For continuous environment:"
print "--------------------------"

results = conteff(3, K)

print "Percentage of gains extracted: %f" % results[0]
print "Frequency of efficient allocation: %f" % results[1]
print


