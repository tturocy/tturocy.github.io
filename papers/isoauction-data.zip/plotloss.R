
data <- read.table("br-earnings.csv", header=TRUE, sep=",")
attach(data)
loss <- bestreply - actual

postscript("loss.eps", horizontal=FALSE, width=5, height=8, onefile=FALSE)
par(mfcol=c(2,1))

plot(sort(loss[type=="sealed"]), 
     xlab="Subject", ylab="Earnings", 
     main="Earnings foregone, sealed implementation")

plot(sort(loss[type=="silent"]), 
     xlab="Subject", ylab="Earnings", 
     main="Earnings foregone, silent implementation")
