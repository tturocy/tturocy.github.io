import random
import itertools

import numpy as np
import scipy.stats
import scipy.optimize
import pandas

import pylab




class EstimationDataset(object):
    def __init__(self, session, partno, df):
        self.session = session
        self.partno = partno
        self._values = self._compute_bid_values(df, session, partno)
        self._counts = self._compute_bid_counts(df[df.participant==partno])['count']

        self.is_fpa = df.is_fpa.max()
        self.gamma = df.gamma.max()

    @property
    def counts(self):   return self._counts
        
    @staticmethod
    def _compute_bid_values(df, session, partno):
        df = df[[ "participant", "period", "own_signal", "own_bid",
                  "other_signal", "other_bid", "gamma", "is_fpa" ]].copy()
        gamma = df.gamma.max()
        
        # Construct empirical distribution of other (signal, bid) pairs
        df['key'] = 1
        grid = pandas.DataFrame([ [ signal, bid, 1 ]
                                for signal in np.arange(20, 1001, 20)
                                for bid in np.arange(10, 1001, 10) ],
                                columns=[ 'signal', 'bid', 'key' ])
        hypo = pandas.merge(grid,
                            df[df.participant!=partno][["other_signal", "other_bid", "gamma", "is_fpa", "key"]],
                            how='outer', left_on='key', right_on='key')

        hypo['value_true'] = (1.0-gamma)*hypo.signal + gamma*hypo.other_signal
        hypo['value_cursed'] = (1.0-gamma)*hypo.signal + gamma*500

        hypo['MB_true'] = 0.5*(hypo.value_true-hypo.bid)*(hypo.other_bid==hypo.bid).astype(int) + \
                          0.5*(hypo.value_true-(hypo.bid-10))*(hypo.other_bid==hypo.bid-10).astype(int) - \
                          10*((hypo.other_bid<hypo.bid) & (hypo.bid>hypo.value_true)).astype(int)
        hypo['MB_cursed'] = 0.5*(hypo.value_cursed-hypo.bid)*(hypo.other_bid==hypo.bid).astype(int) + \
                            0.5*(hypo.value_cursed-(hypo.bid-10))*(hypo.other_bid==hypo.bid-10).astype(int) - \
                            10*((hypo.other_bid<hypo.bid) & (hypo.bid>hypo.value_cursed)).astype(int)
        hypo['MC_true'] = 10*((hypo.other_bid<hypo.bid) & (hypo.bid<=hypo.value_true)).astype(int)
        hypo['MC_cursed'] = 10*((hypo.other_bid<hypo.bid) & (hypo.bid<=hypo.value_cursed)).astype(int)
        values = hypo.groupby([ 'signal', 'bid' ]).mean().reset_index()
        values = values[['signal', 'bid',
                         'MB_true', 'MB_cursed', 'MC_true', 'MC_cursed' ]]

        values['MBsum_true'] = np.cumsum(values.groupby('signal')['MB_true'])
        values['MBsum_cursed'] = np.cumsum(values.groupby('signal')['MB_cursed'])
        values['MCsum_true'] = np.cumsum(values.groupby('signal')['MC_true'])
        values['MCsum_cursed'] = np.cumsum(values.groupby('signal')['MC_cursed'])
        values.set_index([ 'signal', 'bid' ], inplace=True)
        return values

    @staticmethod
    def _compute_bid_counts(df):
        counts = df[["own_signal", "own_bid"]].groupby(["own_signal", "own_bid"]).aggregate(len)
        counts = pandas.DataFrame(counts)
        counts.rename(inplace=True, columns={ 0: 'count' })
        bids = pandas.DataFrame([ [ signal, bid, None ]
                                    for signal in np.arange(20, 1001, 20)
                                    for bid in np.arange(10, 1001, 10) ],
                                columns=[ 'signal', 'bid', 'count' ])
        bids.set_index([ 'signal', 'bid' ], inplace=True)
        bids.update(counts)
        bids.fillna(0, inplace=True)
        return bids

    def empirical_payoffs(self, chi, alp):
        df = self._values[['MBsum_true']].copy()
        df.rename(columns={ 'MBsum_true': 'payoff' }, inplace=True)
        df['payoff'] -= alp*self._values['MCsum_true']
        df['payoff'] *= (1.0-chi)
        df['payoff'] += chi*(self._values['MBsum_cursed']-alp*self._values['MCsum_cursed'])
        return df
    
    def best_response(self, chi, alp):
        payoffs = self.empirical_payoffs(chi, alp)
        argmax = payoffs.groupby(level=0)["payoff"].apply(lambda x: x.idxmax())
        return argmax.apply(lambda x: x[1])

    def log_logit_probs(self, lam, chi, alp):
        payloss = lam*(self.empirical_payoffs(chi, alp).groupby(level=0).transform(lambda x: x-x.max()))
        # pmax is the log-probability of the best response
        pmax = np.log(np.reciprocal(np.exp(payloss).groupby(level=0).sum()))
        return pmax + payloss

    def logit_probs(self, lam, chi, alp):
        return np.exp(self.log_logit_probs(lam, chi, alp))

    def log_like(self, lam, chi, alp):
        return self._counts.dot(self.log_logit_probs(lam, chi, alp))
    
    def entropy(self, lam, chi, alp):
        H = sum(self.logit_probs(lam, chi, alp)['payoff'] *
                self.log_logit_probs(lam, chi, alp)['payoff'])
        # Each signal has a 1-in-50 chance of occurring
        return np.log(.02) + .02*H

    def relative_entropy(self, lam, chi, alp):
        max_H = np.log(.02)
        min_H = np.log(.0002)
        return (self.entropy(lam, chi, alp) - min_H) / (max_H - min_H)
    
    def callback(self, lam, chi, alp):
        print "%s,%s,%.6f," % (self.session, self.partno,
                               self.relative_entropy(lam, chi, alp)) + \
                 (",".join("%.6f" % v for v in (lam,chi,alp))) + (",%.6f" % self.log_like(lam,chi,alp))
        sys.stdout.flush()


class BidFunction(object):
    def __init__(self, lam, chi, alp, dataset):
        self.lam = lam
        self.chi = chi
        self.alp = alp
        self.dataset = dataset

        self.is_fpa = self.dataset.is_fpa
        self.gamma = self.dataset.gamma

    @classmethod
    def _estimate_max_like(cls, dataset, with_chi=True, with_alp=True):
        # If we are not estimating other parameters, we don't need to try
        # multiple starting points for lambda
        #start_lam = [ 0.2, 0.4, 0.6, 0.8 ] if with_chi or with_alp else [ 0.2 ]
        #start_chi = [ 0.2, 0.4, 0.6, 0.8 ] if with_chi else [ 0.0 ]
        #start_alp = [ 0.2, 0.4, 0.6, 0.8 ] if with_alp else [ 0.0 ]
        start_lam = [ 10.0 ]
        start_chi = [ 0.5 ] if with_chi else [ 0.0 ]
        start_alp = [ 0.5 ]
        dataset.callback(0.0, 0.0, 0.0)
        for (lam, chi, alp) in itertools.product(start_lam, start_chi, start_alp):
            result = scipy.optimize.minimize(lambda x: -dataset.log_like(*x),
                                            x0=(lam, chi, alp),
                                            bounds=((0.0, None),
                                                    (0.0, 1.00 if with_chi else 0.0),
                                                    (-2.0, 2.0 if with_alp else 0.0)),
                                            callback=lambda x: dataset.callback(*x),
                                            method='TNC')
            dataset.callback(*result.x)
        return cls(*result.x, dataset=dataset)
        
    @classmethod
    def estimate(cls, df, session, partno):
        df = df[[ "participant", "period", "own_signal", "own_bid", "other_signal", "other_bid", "gamma", "is_fpa" ]].copy()
        dataset = EstimationDataset(session, partno, df)
        with_chi = [ True ] if df.gamma.max() > 0.0 else [ False ]
        with_alp = [ True ] if df.is_fpa.max() == 1 else [ False ]

        for (alp, chi) in itertools.product(with_alp, with_chi):
            return cls._estimate_max_like(dataset, with_chi=chi, with_alp=alp)
        
    def behavior_strategy(self):
        return self.dataset.logit_probs(self.lam, self.chi, self.alp)

    def relative_entropy(self):
        return self.dataset.relative_entropy(self.lam, self.chi, self.alp)

    def plot_heatmap(self, path=None, format=None):
        fig = pylab.figure()
        ax = fig.add_subplot(111)
        probslist = 1.0 - np.array(self.behavior_strategy().unstack()).transpose()
        probslist = np.repeat(probslist, 2, axis=1)
        cax = ax.imshow(probslist, cmap=pylab.cm.gray, vmin=0.8, vmax=1.0)
        
        bids, values = np.nonzero(np.transpose(self.dataset.counts.unstack().as_matrix()))
        pylab.plot([ 2*i for i in xrange(50) ],
                   (self.dataset.best_response(self.chi, self.alp) * .1)-1,
                   'k', ls='dashed')
        pylab.plot(2*values, bids, 'ro')
        pylab.plot([ 0, 100 ], [ 0, 100 ], 'k', ls='dotted')
        if self.is_fpa:
            pylab.plot([ 0, 100 ], [ 0, 50 ], 'k', ls='dotted')
            pylab.plot([ 0, 100 ], [ 50*self.gamma, 50 ], 'k', ls='dotted')
        else:
            pylab.plot([ 0, 100 ], [ 50*self.gamma, 100-50*self.gamma ], 'k', ls='dotted')
            
        pylab.xlim([ -0.5, len(probslist[0])-0.5 ])
        pylab.ylim([ 0.5, len(probslist)-0.5 ])

        ax.xaxis.tick_bottom()
        ax.xaxis.set_ticks([ 19, 39, 59, 79, 99 ])
        ax.xaxis.set_ticklabels([ '200', '400', '600', '800', '1000' ])
        ax.set_xlabel("Signal")
        ax.yaxis.set_ticks([ 19, 39, 59, 79, 99 ])
        ax.yaxis.set_ticklabels([ '200', '400', '600', '800', '1000' ])
        ax.set_ylabel("Bid")

        pylab.text(1.0, 95.0,
                   r"ses=%s p=%s $H$=%.3f $\chi$=%.3f $\alpha$=%.3f" %
                   (session.replace("BAVA_", ""), part,
                    self.relative_entropy(), bidfn.chi, bidfn.alp))

        if path is not None:
            pylab.savefig(path, format=format)
        else:
            pylab.show()
        pylab.close()
    
def prepare_dataset():
    df = pandas.read_csv("../data/alldata.csv")
    # Rescale bids and signals to be in pence (so they are integers)
    for col in [ 'own_signal', 'own_bid', 'other_signal', 'other_bid' ]:
        df[col] = df[col].apply(lambda x: int(round(x*100))).astype(int)
    return df

if __name__ == '__main__':
    import sys

    df = prepare_dataset()
    for ((session, part), data) in df.groupby([ 'session', 'participant' ]):
        if data['is_fpa'].max() == 0: continue
        bidfn = BidFunction.estimate(df[df.session==session], session, part)
        bidfn.plot_heatmap("%s-%s.eps" % (session, part), format='eps')
        bidfn.plot_heatmap("%s-%s.pdf" % (session, part), format='pdf')

        
