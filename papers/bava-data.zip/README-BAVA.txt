Data and supplementary source code for
Turocy and Cason, "Bidding in first-price and second-price interdependent-values auctions:
A laboratory experiment"
This version: 4 December 2015


This archive contains three files:

* alldata.csv: Full data for all sessions.
* logitfit-FPA.py: Fitting of logit bid functions for first-price auctions.
* logitfit-SPA.py: Fitting of logit bid functions for second-price auctions

The latter two scripts are written in Python, and require the SciPy Stack:
http://www.scipy.org/stackspec.html

The file alldata.csv is made available under the Open Data Commons
Attribution License: http://opendatacommons.org/licenses/by/1.0

The scripts are made available under the GNU General Public License,
version 2 (or a later version, at the user's option):
http://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html


